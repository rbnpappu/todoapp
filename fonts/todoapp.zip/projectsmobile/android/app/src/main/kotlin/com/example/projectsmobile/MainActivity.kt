package com.example.projectsmobile

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
